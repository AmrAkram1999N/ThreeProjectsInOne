<?php

namespace App\Http\Controllers;

use App\Http\Traits\HttpRequest;
use App\Http\Traits\TelegramComponents;
use App\Models\Account;

class TelegramController extends Controller
{
    use HttpRequest;
    use TelegramComponents;

    public function webhook()
    {
        return $this->apiRequest('setWebhook', [
            'url' => url(route('webhook')),
        ]) ? ['Success'] : ['Something went Wrong'];
    }

    public function index()
    {
        $result = json_decode(file_get_contents('php://input'));
        $action = $result->message->text;
        $user_id = $result->message->from->id;

        $account = Account::where('telegram_id', $user_id)->first();

        if ($account) {

            if ($action == '/start') {
                $this->start($user_id);
            }

            if ($action == '🗂 File_Manager_Service') {
                $this->file_manager($user_id);
            }

            if ($action == '🗂 My Folders') {
                $this->folders($account, $user_id);
            }

            if ($action == '📝 My Files') {
                $this->files($account, $user_id);
            }

            if ($action == '⛓ Short_Link_Service') {
                $this->short_link_service($user_id);
            }

            if ($action == '⛓ Your Links') {
                $this->links($account, $user_id);
            }

            // Back to menu
            if($action == '🔰 Main Menu'){
                $this->main($user_id);
            }
        } else {
            $this->TelegramAuth($action, $user_id);
        }

    }

    public function TelegramAuth($action, $user_id)
    {
        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => "What is username on website?",
        ]);
        $add_account = Account::where('username', $action)->first();

        if ($add_account == null) {

            $this->apiRequest('sendMessage', [
                'chat_id' => $user_id,
                'text' => "This username is not correct!",
            ]);

        } else {

            $add_account->update([
                'telegram_id' => $user_id,
            ]);

            $this->start($user_id);
        }
    }

    public function start($user_id)
    {
        $text = 'Welcome you in Website Services Site, choose your service from below buttons!';
        $option = [
            ['🗂 File_Manager_Service'],
            ['⛓ Short_Link_Service'],
        ];

        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => $text,
            'reply_markup' => $this->keyboard($option),
        ]);
    }

    public function file_manager($user_id)
    {
        $text = 'Welcome you in your folder_system!!';
        $option = [
            ['🗂 My Folders'],
            ['📝 My Files'],
            ['🔰 Main Menu'],
        ];

        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => "🗂",
        ]);

        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => $text,
            'reply_markup' => $this->keyboard($option),
        ]);
    }
    public function short_link_service($user_id)
    {
        $text = 'Welcome you in your short_link_service!!';
        $option = [
            ['⛓ Your Links'],
            ['🔰 Main Menu'],
        ];

        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => "⛓",
        ]);

        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => $text,
            'reply_markup' => $this->keyboard($option),
        ]);
    }
    public function links($account, $user_id)
    {
        $numbers_of_links = 0;
        $text = "Your Links:";
        $option = [['🔰 Main Menu']];
        $Short_links = $account->Short_Links;

        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => $text,
        ]);

        if($Short_links)
        {
            foreach ($Short_links as $link) {
                $numbers_of_links = $numbers_of_links + 1;
                $this->apiRequest('sendMessage', [
                    'chat_id' => $user_id,
                    'text' => "Website Name: $link->web_site_name" . "\nOld Url: $link->url_old" . "\nNew Url: $link->url_new" . "\nNumber of visitors: $link->clicks",
                ]);
            }

            $this->apiRequest('sendMessage', [
                'chat_id' => $user_id,
                'text' => "You have $numbers_of_links links",
                'reply_markup' => $this->keyboard($option),
            ]);
        }else
        {
            $this->apiRequest('sendMessage', [
                'chat_id' => $user_id,
                'text' => "You don't have links yet",
                'reply_markup' => $this->keyboard($option),
            ]);
        }

    }
    public function folders($account, $user_id)
    {
        $numbers_of_Folders = 0;
        $text = "Your Folders:";
        $option = [['🔰 Main Menu']];
        $Folders = $account->Folders;

        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => $text,
        ]);

        if($Folders)
        {
            foreach ($Folders as $Folder) {
                $numbers_of_Folders = $numbers_of_Folders + 1;
                $this->apiRequest('sendMessage', [
                    'chat_id' => $user_id,
                    'text' => $Folder->folder_name,
                ]);
            }

            $this->apiRequest('sendMessage', [
                'chat_id' => $user_id,
                'text' => "You have $numbers_of_Folders folders",
                'reply_markup' => $this->keyboard($option),
            ]);
        }else
        {
            $this->apiRequest('sendMessage', [
                'chat_id' => $user_id,
                'text' => "You don't have folders",
                'reply_markup' => $this->keyboard($option),
            ]);
        }

    }

    public function files($account, $user_id)
    {
        $numbers_of_Files = 0;
        $text = "Your Files:";
        $option = [['🔰 Main Menu']];
        $Files = $account->Files;

        $this->apiRequest('sendMessage', [
            'chat_id' => $user_id,
            'text' => $text,
        ]);
        if ($Files) {
            foreach ($Files as $File) {
                $numbers_of_Files = $numbers_of_Files + 1;

                $this->apiRequest('sendMessage', [
                    'chat_id' => $user_id,
                    'text' => "📝 Name: $File->file_name"  . "\n🗂Folder: $File->main_folder" ."\n🧩Extension: $File->file_type" . "\n📊Size: $File->file_size\n****************************",
                ]);
            }

            $this->apiRequest('sendMessage', [
                'chat_id' => $user_id,
                'text' => "You have $numbers_of_Files folders",
                'reply_markup' => $this->keyboard($option),
            ]);
        } else {
            $this->apiRequest('sendMessage', [
                'chat_id' => $user_id,
                'text' => "You don't have files",
                'reply_markup' => $this->keyboard($option),
            ]);
        }

    }

    public function main($user_id)
    {
        $this->start($user_id);
    }
}
