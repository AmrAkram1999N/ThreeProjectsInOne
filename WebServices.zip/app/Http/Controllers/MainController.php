<?php

namespace App\Http\Controllers;

use App\Http\Traits\lang;
use App\Models\BackService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MainController extends Controller
{
    protected $Model = "User";
    use lang;

    protected $lang;

    public function __construct()
    {
        $this->lang = $this->lang();
        if (request()->is('Chain/Account/*')) {
            $this->Model = 'Account';
        }
    }

    public function CoverPage(Request $request)
    {

        Auth::guard('account')->logout();
        return view('ProjectFiles.Public.CoverPage', [
            'Model' => $this->Model,
        ]);
    }

    public function WebsiteServices()
    {

        return view('ProjectFiles.Public.WebsiteServices');
    }

    public function LoginPage()
    {

        return view('ProjectFiles.Public.LoginPage');
    }

    public function RegisterPage()
    {
        return view('ProjectFiles.Public.RegisterPage');
    }

    public function User_Dash()
    {
        Auth::guard('account')->logout();

        $username = 'yes';
        $user = Auth::guard('web')->user();
        $Account_Check_Username = "user_name_$user->id";
        $servicesAccount = $user->Services;

        return view('ProjectFiles.Auth.User.User_Dash', [
            'Model' => $this->Model,
            'Services' => $servicesAccount,
            'username' => $Account_Check_Username,
        ]);
    }

    public function Account_Dash()
    {
        $Page_Name = 'Account_Dashboard';
        $account = Auth::guard('account')->user();
        $AccountServices = $account->Services;

        return view('ProjectFiles.Auth.Account.Account_Dash', [
            'AccountServices' => $AccountServices,
            'Page_Name' => $Page_Name,
        ]);
    }

    public function registerService()
    {
        return view('ProjectFiles.Auth.User.RegisterPage');
    }

    public function Short_Link_Service()
    {
        $account = Auth::guard('account')->user();
        $ShortLink = $account->Short_Links;
        return view('ProjectFiles.Auth.Account.ShortLink', [
            'ShortLink' => $ShortLink,
            'account' => $account,

        ]);
    }

    public function File_Manager_Service()
    {
        $account = Auth::guard('account')->user();
        $Folders = $account->Folders;

        $Files = $account->Files->where('main_folder', "File_Manager_Service");

        return view('ProjectFiles.Auth.Account.File_Manager', [
            'account' => $account,
            'Root' => "File_Manager_Service",
            'Folders' => $Folders,
            'Files' => $Files,
        ]);
    }

    public function Back_Cards_Service()
    {
        $account = Auth::guard('account')->user();
        $Cards =BackService::all();

        return view('ProjectFiles.Auth.Account.Back_Cards_Service', [
            'Cards' => $Cards,
            'account' => $account,
        ]);
    }
    public function User_Profile()
    {
        $Page_Name = 'User_Profile';
        $user = Auth::guard('web')->user();
        $UserProfile = $user->User_Profile;

        return view('ProjectFiles.Auth.User.UserProfilePage', [
            'UserProfile' => $UserProfile,
            'routeImage' => 'Chain.User.Auth.ChangePhoto',
            'Page_Name' => $Page_Name,
        ]);
    }

    public function Account_Profile()
    {
        $Page_Name = 'Account_Profile';
        $account = Auth::guard('account')->user();
        $AccountProfile = $account->Account_Profile;
        $Services = $account->Services->where('account_id', $account->id);

        return view("ProjectFiles.Auth.Account.AccountProfilePage", [
            'AccountProfile' => $AccountProfile,
            'routeImage' => 'Chain.Account.Auth.ChangePhoto',
            'routeUpdate' => 'Chain.Account.Auth.update',
            'Services' => $Services,
            'Page_Name' => $Page_Name,

        ]);
    }

    public function cardView($lang = 'en')
    {
        $language = $this->lang($lang);
        return view('ProjectFiles.Auth.Account.cardView', [
            'number' => 1,
            'lang' => $language,
        ]);
    }

    //Project System
    public function databaseSystem()
    {
        return view('ProjectSystem.DatabaseMap');
    }
    public function interfaceSystem()
    {
        return view('ProjectSystem.InterfaceMap');
    }
    public function controllerModelSystem()
    {
        return view('ProjectSystem.Controller&Models');
    }
}
