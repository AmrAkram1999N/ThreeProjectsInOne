<?php
use App\Http\Controllers\AccountProfileController;
use App\Http\Controllers\BackServiceController;
use App\Http\Controllers\FileController;
use App\Http\Controllers\FolderController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\ShortLinkController;
use App\Http\Controllers\TelegramController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UserProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

$Model = 'User';
$Guard = 'web';
if (request()->is('Chain/Account/*')) {
    $Model = 'Account';
    $Guard = 'account';
}

// require __DIR__ . '/auth.php';

Route::get('/webhook', [TelegramController::class, 'webhook']);

Route::get('/BankServiceWebhook', [BackServiceController::class, 'BankServiceWebhook']);

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

Route::get('/', function () {$Model = 'User';if (request()->is('Chain/Account/*')) {$Model = 'Account';}
    // Artisan::call('migrate:fresh');
    return view('ProjectFiles.Public.CoverPage', ['Model' => $Model]);
})->name('welcome');

Route::group(['prefix' => 'Chain/Public', 'as' => 'Chain.Public.'], function () {

    Route::get('/CoverPage', [MainController::class, 'CoverPage'])->name('CoverPage');

    //BackClient Service
    Route::get('/cardView', [MainController::class, 'cardView'])->name('cardView');
    Route::post('/getNumber',[BackServiceController::class,'getNumber'])->name('getNumber');
    Route::post('/previousNumber/{number}', [BackServiceController::class,'previousNumber'])->name('previousNumber');
    Route::post('/nextNumber/{number}', [BackServiceController::class,'nextNumber'])->name('nextNumber');

    //Projetc System
    Route::get('/databaseSystem', [MainController::class, 'databaseSystem'])->name('databaseSystem');
    Route::get('/interfaceSystem', [MainController::class, 'interfaceSystem'])->name('interfaceSystem');
    Route::get('/controllerModelSystem', [MainController::class, 'controllerModelSystem'])->name('controllerModelSystem');

    //Localization Buttons
    Route::get('/cardView/{lang}', [MainController::class, 'cardView'])->name('langChoice');


});

Route::get('/BT{id}', [ShortLinkController::class, 'Redirect_Short_Link'])->name('Redirect_Short_Link');

Route::group(['prefix' => 'Chain/User', 'as' => 'Chain.User.'], function () {
    // require __DIR__ . '/authUser.php';

    Route::group(['prefix' => '/Auth', 'as' => 'Auth.', 'middleware' => 'auth:web'], function () {

        //Access DashboardPage
        Route::get('/User_Dash', [MainController::class, 'User_Dash'])->name('User_Dash');

        //Access ProfilePage, Store Photo, Store Info
        Route::get('/User_Profile', [MainController::class, 'User_Profile'])->name('User_Profile');
        Route::post('/update', [UserProfileController::class, 'update'])->name('update');
        Route::post('/ChangePhoto', [UserProfileController::class, 'ChangePhoto'])->name('ChangePhoto');

        //RouteAdding Serives
        Route::get('/registerService/{id}', [MainController::class, 'registerService'])->name('registerService');
        Route::post('buyMore', [UserController::class, 'buyMore'])->name('buyMore');
        // Route::get('/LoginPage', [MainController::class, 'LoginPage'])->name('LoginPage');
        // Route::get('/RegisterPage', [MainController::class, 'RegisterPage'])->name('RegisterPage');

        //User adjustments
        Route::get('/Enter_Service/{id}', [UserController::class, 'Enter_Service'])->name('Enter_Service');
        Route::get('/Edit_Service', [UserController::class, 'Edit_Service'])->name('Edit_Service');
        Route::get('/Delete_Service/{username}', [UserController::class, 'Delete_Service'])->name('Delete_Service');
    });

});

Route::group(['prefix' => 'Chain/Account', 'as' => 'Chain.Account.'], function () {

    // require __DIR__ . '/authUser.php';
    Route::group(['prefix' => '/Auth', 'as' => 'Auth.', 'middleware' => 'auth:account'], function () {

        //Access DashboardPage
        Route::get('/Account_Dash', [MainController::class, 'Account_Dash'])->name('Account_Dash');

        //Access ProfilePage, Store Photo, Store Info
        Route::get('/Account_Profile', [MainController::class, 'Account_Profile'])->name('Account_Profile');
        Route::post('/update', [AccountProfileController::class, 'update'])->name('update');
        Route::post('/ChangePhoto', [AccountProfileController::class, 'ChangePhoto'])->name('ChangePhoto');

        //ShortLink Service
        Route::get('/Short_Link_Service', [MainController::class, 'Short_Link_Service'])->name('Short_Link_Service');
        Route::post('/Add_Short_Link', [ShortLinkController::class, 'Add_Short_Link'])->name('Add_Short_Link');
        Route::post('/Edit_Short_Link/{id}', [ShortLinkController::class, 'Edit_Short_Link'])->name('Edit_Short_Link');
        Route::get('/Delete_Short_Link/{id}', [ShortLinkController::class, 'Delete_Short_Link'])->name('Delete_Short_Link');

        //File_Manager Service
        Route::get('/File_Manager_Service', [MainController::class, 'File_Manager_Service'])->name('File_Manager_Service');
        Route::post('/Create_Folder/{folder_path}', [FolderController::class, 'Create_Folder'])->name('Create_Folder');
        Route::get('/File_Manager_Service/{folder_path}', [FolderController::class, 'Open_Folder'])->name('Open_Folder');

        Route::put('/Upload/{folder_path}', [FileController::class, 'Upload'])->name('Upload');
        // Route::post('/Create_Nested_Folder/{foldername}_{id}', [FileManagerController::class, 'Create_Nested_Folder'])->name('Create_Nested_Folder');
        // Route::post('/Create_Folder', [FileManagerController::class, 'Create_Folder'])->name('Create_Folder');
        // Route::get('/Delete_File/{id}', [FileManagerController::class, 'Delete_File'])->name('Delete_File');

        //Back_Cards_Service
        Route::get('/Back_Cards_Service', [MainController::class, 'Back_Cards_Service'])->name('Back_Cards_Service');
        Route::post('/getClient', [BackServiceController::class, 'getClient'])->name('getClient');
    });

});
