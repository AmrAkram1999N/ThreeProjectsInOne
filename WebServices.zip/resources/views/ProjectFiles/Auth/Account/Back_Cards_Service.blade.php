<x-Account-layout>

    <x-slot name="PageName">Back_Cards_Service</x-slot>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><span class="text-warning">{{ $account->name }}:</span> <span
                class="fs-3">Back_Cards_Service</span> </h1>
        <div class="btn-toolbar mb-2 mb-md-0">

            <div class="btn-group me-2">
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>

        </div>
    </div>


    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr class="text-center">
                    <th scope="col">id</th>
                    <th scope="col">clientname</th>
                    <th scope="col">clientnumber</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($Cards as $Card)
                    <tr class="text-center">
                        <td> {{ $Card->id }} </td>
                        <td> {{ $Card->clientname }} </td>
                        <td> {{ $Card->clientnumber }} </td>
                    </tr>
                @endforeach

            </tbody>
        </table>

        <form action="{{ route('Chain.Account.Auth.getClient') }}" method="POST">
            @csrf
            <button class="btn btn-sm btn-outline-secondary bg-black" type="submit" role="button">
                Get a Client
            </button>
        </form>

        @if (Session::has('status'))
            <div class="alert alert-warning text-black">
                {{ Session::get('status') }}
            </div>
        @endif
</x-Account-layout>
