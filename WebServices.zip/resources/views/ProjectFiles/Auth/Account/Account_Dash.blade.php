<x-Account-layout>



    <x-slot name="PageName">Account_Dashboard</x-slot>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Your_Services</h1>
        <div class="btn-toolbar mb-2 mb-md-0">

        <div class="btn-group me-2">
                {{-- <a type="button" class="btn btn-sm btn-outline-secondary"
                    href="{{ route('Chain.Public.WebsiteServices') }}">Buy More</a> --}}
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>

            {{-- <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
            </button> --}}
        </div>
    </div>

    {{-- <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas> --}}


    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr class="text-center">
                    <th>ID</th>
                    <th scope="col">Name_Service</th>
                    <th scope="col">Your_boss</th>
                    <th scope="col">Enter_The_Work</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($AccountServices as $Service)
                    <tr class="text-center">

                        <td>{{ $Service->id }}</td>
                        <td>{{ $Service->name_service }}</td>
                        <td>{{ $Service->User->name }}</td>
                        {{-- <td><x-editButton Service="{{$link->id}}"></x-editButton></td> --}}
                        <td><a class="btn btn-sm btn-outline-secondary text-success" href="{{ route('Chain.Account.Auth.'. $Service->name_service) }}">Enter</a></td>
                    </tr>
                @endforeach

            </tbody>




        </table>
    </div>

</x-Account-layout>
