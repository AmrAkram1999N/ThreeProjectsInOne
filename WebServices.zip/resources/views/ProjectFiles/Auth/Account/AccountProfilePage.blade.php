<x-Account-layout >
    <x-slot name="PageName">Account_Profile</x-slot>
    <style>
        .inf-content {
            border: 1px solid #DDDDDD;
            -webkit-border-radius: 10px;
            -moz-border-radius: 10px;
            border-radius: 10px;
            box-shadow: 7px 7px 7px rgba(0, 0, 0, 0.3);
            margin-top: 10px;
        }

    </style>



    <div class="container bootstrap snippets bootdey">
        <div class="panel-body inf-content">
            @if (count($errors) > 0)

                @foreach ($errors->all() as $error)
                    <div class="alert alert-danger">{{ $error }}</div>
                @endforeach

            @endif
            <div class="row">
                <div class="col-md-4">

                    <img alt="" style="width:600px;" title="" class="img-circle img-thumbnail isTooltip"
                        src="@if ($AccountProfile->photo != null) {{ $AccountProfile->photo }} @else https://www.bootdey.com/img/Content/avatar/avatar7.png @endif " data-original-title="Usuario">
                    <ul title="Ratings" class="list-inline ratings text-center">
                        <li class="mt-3"><a href="#"><span class="glyphicon glyphicon-star"><x-input-form routeImage="{{ $routeImage }}"></x-input-form></span></a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-star"></span></a></li>
                    </ul>

                </div>

                <div class="col-md-6">
                    <h1>Information</h1><br>
                    <div class="table-responsive">
                        <table class="table table-user-information">
                            <tbody>
                                <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-asterisk text-primary"></span>
                                            Identificacion
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        405236530
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-user  text-primary"></span>
                                            Name
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        {{ $AccountProfile->name_employee }}
                                    </td>
                                </tr>
                                {{-- <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-cloud text-primary"></span>
                                            Lastname
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        Bootstrap
                                    </td>
                                </tr> --}}

                                <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-bookmark text-primary"></span>
                                            Username
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        {{ $AccountProfile->username }}
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-bookmark text-primary"></span>
                                            Password
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        {{ Auth::guard('account')->user()->getAuthPassword() }}
                                    </td>
                                </tr>



                                <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-bookmark text-primary"></span>
                                            Phone_Number
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        {{ $AccountProfile->phone_number }}
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-eye-open text-primary"></span>
                                            Roles
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        @foreach($Services as $service)
                                            {{"(" .$service->name_service ."),  "}}
                                        @endforeach
                                    </td>
                                </tr>
                                {{-- <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-envelope text-primary"></span>
                                            Email
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        noreply@email.com
                                    </td>
                                </tr> --}}
                                <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-calendar text-primary"></span>
                                            Created_At
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        {{ date('d-m-Y', strtotime($AccountProfile->created_at));  }}
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <strong>
                                            <span class="glyphicon glyphicon-calendar text-primary"></span>
                                            Modified_At
                                        </strong>
                                    </td>
                                    <td class="text-primary">
                                        {{ date('d-m-Y', strtotime($AccountProfile->updated_at));  }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <x-update_form routeUpdate="{{ $routeUpdate }}" phonenumber="{{$AccountProfile->phone_number}}" username="{{$AccountProfile->username}}" nameemployee="{{$AccountProfile->name_employee}}"></x-update_form>
                </div>
            </div>
        </div>
    </div>

</x-Account-layout>
