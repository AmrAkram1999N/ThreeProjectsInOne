<x-Account-layout>
    <x-slot name="PageName">Short_Link_Service</x-slot>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><span class="text-warning">{{$account->name}}:</span> <span class="fs-3">Short_Link_Service</span> </h1>
        <div class="btn-toolbar mb-2 mb-md-0">

            <div class="btn-group me-2">
                {{-- <a type="button" class="btn btn-sm btn-outline-secondary"
                    href="{{ route('Chain.Public.WebsiteServices') }}">Buy More</a> --}}
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>

            {{-- <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
            </button> --}}
        </div>
    </div>

    {{-- <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas> --}}

    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr class="text-center">
                    <th>Order</th>
                    <th scope="col">Web_site_name</th>
                    <th scope="col">Url_old</th>
                    <th scope="col">Url_new</th>
                    <th scope="col">Clicks_Number</th>
                    <th scope="col">Editting</th>
                    <th scope="col">Result</th>
                    <th scope="col">Deleting</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                @foreach ($ShortLink as $link)
                    <tr class="text-center">

                        <td>{{ $link->id }}</td>
                        <td>{{ $link->web_site_name }}</td>
                        <td>{{ $link->url_old }}</td>
                        <td><a target="_blank" href="{{ route('Redirect_Short_Link', $link->id) }}">{{ $link->url_new }}</a></td>
                        <td> {{ $link->clicks }} </td>
                        <td style="text-align: left">
                            <x-editButton  link="{{ $link->id }}"></x-editButton>
                        </td>
                        <td><a target="_blank" class="btn btn-sm btn-outline-secondary text-success"
                                href="{{ route('Redirect_Short_Link', $link->id) }}">Show</a></td>
                        <td><a  class="btn btn-sm btn-outline-secondary text-danger"
                                href="{{ route('Chain.Account.Auth.Delete_Short_Link', $link->id) }}">Delete</a></td>
                    </tr>
                @endforeach

            </tbody>
        </table>

        <x-addButton></x-addButton>
        <div>
            @error('url_request')
                <small class="text-danger fw-bold" style="font-size: 15px;">
                    {{ $message }}</small>
            @enderror
        </div>

    </div>
</x-Account-layout>
