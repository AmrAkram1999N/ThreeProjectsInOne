<x-Account-layout>



    {{-- @if (count($errors) > 0)

        @foreach ($errors->all() as $error)
            <div class="alert alert-danger">{{ $error }}</div>
        @endforeach

    @endif --}}
    <link rel="stylesheet" href="/css/dropdown.css">
    <x-slot name="PageName">File_Manager_Service</x-slot>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><span class="text-primary">{{ $account->name }}:</span> <span
                class="fs-3">File_Manager_Service</span> </h1>
        <div class="btn-toolbar mb-2 mb-md-0">

            <div class="btn-group me-2">
                {{-- <a type="button" class="btn btn-sm btn-outline-secondary"
                    href="#">Upload Files</a> --}}

                <x-Upload_Button path="{{ $Folder_Path }}"></x-Upload_Button>

                <x-Create_Button folder="{{ $Folder_Path }}"></x-Create_Button>
                {{-- <x-Create_File_Button folder="{{$Folder_Name}}"></x-Create_File_Button> --}}

                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>

            {{-- <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
            </button> --}}
        </div>
    </div>

    {{-- <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas> --}}
    @error('folder_name')

        <div class="alert alert-danger alert-dismissible fade show">
            <strong>Error!</strong> {{ $message }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @enderror
    <div class="table-responsive">
        <table class="table  table-sm">
            <thead>
                <tr class="text-left">
                    <th><input type="checkbox"></th>
                    <th>File_Name </th>
                    <th>File_Size</th>
                    <th>Date</th>


                </tr>
            </thead>
            <tbody>

                @foreach ($Sub_Folders as $Sub_Folder)

                    <tr class="text-left">
                        <td><input type="checkbox"></td>
                        <td>
                            <a href="{{ route('Chain.Account.Auth.Open_Folder', $Sub_Folder->folder_path) }}"
                                class="ms-1 text-warning "  style="text-decoration: none; color:black;">
                                <span data-feather="folder"></span>
                            </a>
                            <a href="{{ route('Chain.Account.Auth.Open_Folder', $Sub_Folder->folder_path) }}"
                                class="ms-1" style="text-decoration: none; color:black;">
                                {{ $Sub_Folder->folder_name }}
                            </a>
                        </td>
                        <td>
                            <a href="" style="text-decoration: none; color:black; ">{{ $Sub_Folder->folder_size }}</a>
                        </td>
                        <td>
                            <a href="" style="text-decoration: none; color:black; ">{{ $Sub_Folder->created_at }}</a>
                        </td>

                    </tr>
                @endforeach


                @foreach ($Files as $File)

                    <tr class="text-left">

                        <td><input type="checkbox"></td>
                        <td>
                            <a target="_blank" href="{{$File->file_path_directory}}"
                                class="ms-1 text-warning" style="text-decoration: none; color:black;">
                                <i class="{{$File->icon}}"></i>

                            </a>
                            <a target="_blank" href="{{$File->file_path_directory}}"
                                class="ms-1" style="text-decoration: none; color:black;">
                                {{ $File->file_name }}
                            </a>
                        </td>
                        <td>
                            <a href="" style="text-decoration: none; color:black; ">{{ $File->file_size }}</a>
                        </td>
                        <td>
                            <a href="" style="text-decoration: none; color:black; ">{{ $File->created_at }}</a>
                        </td>
                        <td></td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div>
            @error('file_request')
                <small class="text-danger fw-bold" style="font-size: 15px;">
                    {{ $message }}</small>
            @enderror

        </div>

        <div>
            @error('file_name')
                <small class="text-danger fw-bold" style="font-size: 15px;">
                    {{ $message }}</small>
            @enderror
        </div>
    </div>
</x-Account-layout>
