<x-User-layout>
    <x-slot name="PageName">User_Dashboard</x-slot>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Purchased Services</h1>
        <div class="btn-toolbar mb-2 mb-md-0">

            <div class="btn-group me-2">
                {{-- <a type="button" class="btn btn-sm btn-outline-secondary"
                    href="{{ route('Chain.Public.WebsiteServices') }}">Buy More</a> --}}
                <x-buyMore></x-buyMore>
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>

            {{-- <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
            </button> --}}
        </div>
    </div>

    {{-- <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas> --}}

    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name_Service</th>
                    <th scope="col">Username</th>
                    <th scope="col">Name_Employee</th>
                    <th scope="col">Phone_Number</th>
                    {{-- <th scope="col">Editting</th> --}}
                    <th scope="col">Show_Service</th>
                    <th scope="col">Deleting</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($Services as $Service)
                    <tr>
                        <td>#</td>
                        <td>{{ $Service->name_service }}</td>
                        <td>{{ $Service->username }}</td>
                        <td>{{ $Service->name_employee }}</td>
                        <td>{{ $Service->phone_number }}</td>
                        @if ($Service->username == $username)
                            <td><a class="btn btn-sm btn-outline-secondary text-black"
                                    href="{{ route('Chain.User.Auth.Enter_Service', $username) }}">Add_Password</a></td>
                        @endif

                        {{-- <td><a class="btn btn-sm btn-outline-secondary text-black" href="{{route('Chain.User.Auth.Edit_Service', $Service->username)}}">Edit</a></td> --}}

                        <td><a target="_blank" class="btn btn-sm btn-outline-secondary text-success"
                                href="{{ route('Chain.Account.Auth.Account_Dash') }}">Show</a></td>
                        <td><a class="btn btn-sm btn-outline-secondary text-danger"
                                href="{{ route('Chain.User.Auth.Delete_Service', $Service->username) }}">Delete</a></td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        @if (Session::has('warning'))
        <div class="alert alert-warning text-black">
            {{ Session::get('warning') }}
        </div>
        @endif
    </div>

</x-User-layout>
