<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Signin Template · Bootstrap v5.1</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/sign-in/">



    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

    </style>


    <!-- Custom styles for this template -->
    <link href="/css/signin.css" rel="stylesheet">
</head>

<body class="text-center">
    <main class="form-signin">
        <!-- Validation Errors -->

        <x-auth-validation-errors class="mb-4" :errors="$errors" />

        <form method="POST" action="{{ route('Chain.Account.register') }}">
            @csrf
            <img class="mb-4" src="/brand/bootstrap-logo.svg" alt="" width="72" height="57">
            <h1 class="h3 mb-3 fw-normal">Register Your Service</h1>

            <div class="form-floating">
                <input type="text" id="name" class="form-control @error('name') is-invalid @enderror" name="name"
                    id="floatingInput" placeholder="Enter Your Full Name" :value="old('name')" required autofocus>
                <label for="floatingInput">Name_Employee</label>
                @error('name')
                    <div>
                        <small class="text-danger">
                            {{ $message }}</small>
                    </div>
                @enderror
            </div>

            <div class="form-floating">
                <input type="text" id="username" class="form-control @error('username') is-invalid @enderror" name="username"
                    id="floatingInput" placeholder=" name@example.com" :value="old('username')" required>
                <label for="floatingInput">User Name</label>
                @error('username')

                        <small class="text-danger">
                            {{ $message }}</small>

                @enderror
            </div>

            <div class="form-floating">
                <input type="password" id="password" class="form-control mb-0 @error('password') is-invalid @enderror"
                    name="password" id="floatingPassword" placeholder="Password" name="password" required
                    autocomplete="new-password">
                @error('password')
                    <div>
                        <small class="text-danger">
                            {{ $message }}</small>
                    </div>
                @enderror
                <label for="floatingPassword">Password</label>
            </div>

            <div class="form-floating">
                <input type="password" id="password_confirmation"
                    class="form-control @error('password_confirmation') is-invalid @enderror"
                    name="password_confirmation" id="floatingPassword" placeholder="Password" required>
                @error('password_confirmation')
                    <div>
                        <small class="text-danger">
                            {{ $message }}</small>
                    </div>
                @enderror

                <label for="floatingPassword">Confirm Password</label>
            </div>


            <button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
            <p class="mt-5 mb-3 text-muted">&copy; 2021–2022</p>
        </form>
    </main>



</body>

</html>
