<x-User-layout>
    <x-slot name="PageName">User_Profile</x-slot>

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <div class="container">
        <div class="row flex-lg-nowrap ">
            <div class="col ">
                <div class="row ">
                    <div class="col mb-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="e-profile">
                                    <div class="row">
                                        <div class="col-12 col-sm-auto mb-3">
                                            <div class="mx-auto" style="width: 140px;">

                                                <div class="d-flex justify-content-center align-items-center rounded"
                                                    style="height: 140px; background-color: rgb(233, 236, 239);">
                                                    <img style="width: 140px; height: 140px;" src="
                                                          @if ($UserProfile->photo !=
                                                    null)
                                                    {{ $UserProfile->photo }}
                                                @else
                                                https://www.bootdey.com/img/Content/avatar/avatar7.png
                                                    @endif " alt="">
                                                </div>


                                            </div>
                                        </div>


                                        <div class="col d-flex flex-column flex-sm-row justify-content-between mb-3">
                                            <div class="text-center text-sm-left mb-2 mb-sm-0">
                                                <h4 class="pt-sm-2 pb-1 mb-0 text-nowrap">{{ $UserProfile->fullname }}
                                                </h4>
                                                <p class="mb-0">{{ '@' . $UserProfile->username }}</p>

                                                <div class="mt-2">
                                                    <x-input-form routeImage="{{$routeImage}}"></x-input-form>
                                                </div>

                                                @if (session('status'))
                                                    <strong>

                                                        <small class="text-success" role="alert">
                                                            {{ session('status') }}
                                                        </small>
                                                    </strong>
                                                @endif

                                            </div>
                                            <div class="text-center text-sm-right">
                                                <span class="badge badge-secondary" style="color: green;">administrator</span>
                                                <div class="text-muted"><small>Joined at {{ date('d-m-Y', strtotime($UserProfile->created_at));  }}</small></div>
                                            </div>
                                        </div>


                                    </div>
                                    <ul class="nav nav-tabs">
                                        <li class="nav-item"><a href="" class="active nav-link">Settings</a></li>
                                    </ul>
                                    <div class="tab-content pt-3">
                                        <div class="tab-pane active">
                                            <form class="form" method="POST"
                                                action="{{ route('Chain.User.Auth.update') }}" novalidate="">
                                                @csrf
                                                <div class="row">
                                                    <div class="col">
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Full Name</label>
                                                                    <input
                                                                        class="form-control @error('fullname') is-invalid  @enderror"
                                                                        type="text" name="fullname"
                                                                        placeholder="John Smith"
                                                                        value="{{ $UserProfile->fullname }}">
                                                                    @error('fullname')
                                                                        <small class="text-danger">
                                                                            {{ $message }}</small>
                                                                    @enderror
                                                                </div>
                                                            </div>
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Username</label>
                                                                    <input
                                                                        class="form-control @error('username') is-invalid  @enderror"
                                                                        type="text" name="username"
                                                                        placeholder="johnny.s"
                                                                        value="{{ $UserProfile->username }}">
                                                                    @error('username')
                                                                        <small class="text-danger">
                                                                            {{ $message }}</small>
                                                                    @enderror
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Email</label>
                                                                    <input
                                                                        class="form-control @error('email') is-invalid  @enderror"
                                                                        value="{{ $UserProfile->email }}"
                                                                        name="email" type="text"
                                                                        placeholder="user@example.com">
                                                                    @error('email')
                                                                        <small class="text-danger">
                                                                            {{ $message }}</small>
                                                                    @enderror
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col mb-3">
                                                                <div class="form-group">
                                                                    <label>About</label>
                                                                    <textarea
                                                                        class="form-control @error('bio') is-invalid  @enderror"
                                                                        name="bio" rows="5"
                                                                        placeholder="My Bio">{{ $UserProfile->bio }}</textarea>
                                                                    @error('bio')
                                                                        <small class="text-danger">
                                                                            {{ $message }}</small>
                                                                    @enderror
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                {{-- <div class="row">
                                                    <div class="col-12 col-sm-6 mb-3">
                                                        <div class="mb-2"><b>Change Password</b></div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Current Password</label>
                                                                    <input class="form-control" type="password"
                                                                        placeholder="••••••">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>New Password</label>
                                                                    <input class="form-control" type="password"
                                                                        placeholder="••••••">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Confirm <span
                                                                            class="d-none d-xl-inline">Password</span></label>
                                                                    <input class="form-control" type="password"
                                                                        placeholder="••••••">
                                                                </div>
                                                            </div>
                                                        </div> --}}
                                        </div>
                                        <div class="col-12 col-sm-5 offset-sm-1 mb-3">
                                            <div class="mb-2"><b>Keeping in Touch</b></div>
                                            <div class="row">
                                                <div class="col">
                                                    <label>Email Notifications</label>
                                                    <div class="custom-controls-stacked px-2">
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input"
                                                                id="notifications-blog" checked="">
                                                            <label class="custom-control-label"
                                                                for="notifications-blog">Blog posts</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input"
                                                                id="notifications-news" checked="">
                                                            <label class="custom-control-label"
                                                                for="notifications-news">Newsletter</label>
                                                        </div>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input"
                                                                id="notifications-offers" checked="">
                                                            <label class="custom-control-label"
                                                                for="notifications-offers">Personal
                                                                Offers</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col d-flex justify-content-end">
                                            <button class="btn btn-primary" type="submit">Save Changes</button>
                                        </div>
                                    </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-3 mb-3">
                <div class="card mb-3">
                    <div class="card-body">
                        <div class="px-xl-3">
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                            <button type="submit" class="btn btn-bg btn-danger" >
                                <i class="fa fa-sign-out"></i>
                                <span>Logout</span>
                            </button>
                        </form>
                        </div>
                    </div>
                </div>
                {{-- <div class="card">
                            <div class="card-body">
                                <h6 class="card-title font-weight-bold">Support</h6>
                                <p class="card-text">Get fast, free help from our friendly assistants.</p>
                                <button type="button" class="btn btn-primary">Contact Us</button>
                            </div>
                        </div> --}}
            </div>
        </div>

    </div>
    </div>
    </div>
</x-User-layout>
