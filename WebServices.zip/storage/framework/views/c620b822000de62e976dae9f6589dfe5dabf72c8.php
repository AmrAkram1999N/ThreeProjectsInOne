<?php if (isset($component)) { $__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserLayout::class, []); ?>
<?php $component->withName('User-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('PageName', null, []); ?> User_Dashboard <?php $__env->endSlot(); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Purchased Services</h1>
        <div class="btn-toolbar mb-2 mb-md-0">

            <div class="btn-group me-2">
                
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buyMore','data' => []]); ?>
<?php $component->withName('buyMore'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>

            
        </div>
    </div>

    

    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name_Service</th>
                    <th scope="col">Username</th>
                    <th scope="col">Name_Employee</th>
                    <th scope="col">Phone_Number</th>
                    
                    <th scope="col">Show_Service</th>
                    <th scope="col">Deleting</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $Services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>#</td>
                        <td><?php echo e($Service->name_service); ?></td>
                        <td><?php echo e($Service->username); ?></td>
                        <td><?php echo e($Service->name_employee); ?></td>
                        <td><?php echo e($Service->phone_number); ?></td>
                        <?php if($Service->username == $username): ?>
                            <td><a class="btn btn-sm btn-outline-secondary text-black"
                                    href="<?php echo e(route('Chain.User.Auth.Enter_Service', $username)); ?>">Add_Password</a></td>
                        <?php endif; ?>

                        

                        <td><a target="_blank" class="btn btn-sm btn-outline-secondary text-success"
                                href="<?php echo e(route('Chain.Account.Auth.Account_Dash')); ?>">Show</a></td>
                        <td><a class="btn btn-sm btn-outline-secondary text-danger"
                                href="<?php echo e(route('Chain.User.Auth.Delete_Service', $Service->username)); ?>">Delete</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if(Session::has('warning')): ?>
        <div class="alert alert-warning text-black">
            <?php echo e(Session::get('warning')); ?>

        </div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107)): ?>
<?php $component = $__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107; ?>
<?php unset($__componentOriginal1c033872f6702129cc9a9b857a6606a850d68107); ?>
<?php endif; ?>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/ProjectFiles/Auth/User/User_Dash.blade.php ENDPATH**/ ?>