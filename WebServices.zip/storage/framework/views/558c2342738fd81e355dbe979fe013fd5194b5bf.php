<?php if (isset($component)) { $__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AccountLayout::class, []); ?>
<?php $component->withName('Account-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('PageName', null, []); ?> Short_Link_Service <?php $__env->endSlot(); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><span class="text-warning"><?php echo e($account->name); ?>:</span> <span class="fs-3">Short_Link_Service</span> </h1>
        <div class="btn-toolbar mb-2 mb-md-0">

            <div class="btn-group me-2">
                
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>

            
        </div>
    </div>

    

    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr class="text-center">
                    <th>Order</th>
                    <th scope="col">Web_site_name</th>
                    <th scope="col">Url_old</th>
                    <th scope="col">Url_new</th>
                    <th scope="col">Clicks_Number</th>
                    <th scope="col">Editting</th>
                    <th scope="col">Result</th>
                    <th scope="col">Deleting</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ShortLink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">

                        <td><?php echo e($link->id); ?></td>
                        <td><?php echo e($link->web_site_name); ?></td>
                        <td><?php echo e($link->url_old); ?></td>
                        <td><a target="_blank" href="<?php echo e(route('Redirect_Short_Link', $link->id)); ?>"><?php echo e($link->url_new); ?></a></td>
                        <td> <?php echo e($link->clicks); ?> </td>
                        <td style="text-align: left">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.editButton','data' => ['link' => ''.e($link->id).'']]); ?>
<?php $component->withName('editButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['link' => ''.e($link->id).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </td>
                        <td><a target="_blank" class="btn btn-sm btn-outline-secondary text-success"
                                href="<?php echo e(route('Redirect_Short_Link', $link->id)); ?>">Show</a></td>
                        <td><a  class="btn btn-sm btn-outline-secondary text-danger"
                                href="<?php echo e(route('Chain.Account.Auth.Delete_Short_Link', $link->id)); ?>">Delete</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.addButton','data' => []]); ?>
<?php $component->withName('addButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <div>
            <?php $__errorArgs = ['url_request'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger fw-bold" style="font-size: 15px;">
                    <?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b)): ?>
<?php $component = $__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b; ?>
<?php unset($__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b); ?>
<?php endif; ?>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/ProjectFiles/Auth/Account/ShortLink.blade.php ENDPATH**/ ?>