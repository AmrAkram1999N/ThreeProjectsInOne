<?php if (isset($component)) { $__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AccountLayout::class, []); ?>
<?php $component->withName('Account-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    
    <link rel="stylesheet" href="/css/dropdown.css">

     <?php $__env->slot('PageName', null, []); ?> File_Manager_Service <?php $__env->endSlot(); ?>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">
            <span class="text-primary"><?php echo e($account->name); ?>:</span>
            <span class="fs-3">File_Manager_Service</span>
        </h1>

        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.Upload_Button','data' => ['path' => ''.e($Root).'']]); ?>
<?php $component->withName('Upload_Button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['path' => ''.e($Root).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.Create_Button','data' => ['folder' => ''.e($Root).'']]); ?>
<?php $component->withName('Create_Button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['folder' => ''.e($Root).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>


            
        </div>
    </div>

    

    <?php $__errorArgs = ['folder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

        <div class="alert alert-danger alert-dismissible fade show">
            <strong>Error!</strong> <?php echo e($message); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


    <div class="table-responsive">

        <table class="table  table-sm">
            <thead>
                <tr class="text-left">
                    <th><input type="checkbox"></th>
                    <th>Folder_Name</th>
                    <th>Folder_Size</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $Folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="text-left">

                        <td><input type="checkbox"></td>

                        <td>
                            <a href="<?php echo e(route('Chain.Account.Auth.Open_Folder', $Folder->folder_path)); ?>"
                                class="ms-1 text-warning" style="text-decoration: none; color:black;">
                                <span data-feather="folder"></span>
                            </a>

                            <a href="<?php echo e(route('Chain.Account.Auth.Open_Folder', $Folder->folder_path)); ?>"
                                class="ms-1" style="text-decoration: none; color:black;">
                                <?php echo e($Folder->folder_name); ?>

                            </a>

                        </td>
                        <td>
                            <a href="" style="text-decoration: none; color:black; "><?php echo e($Folder->folder_size); ?></a>
                        </td>
                        <td><a href="" style="text-decoration: none; color:black; "><?php echo e($Folder->created_at); ?></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $Files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $File): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="text-left">

                        <td><input type="checkbox"></td>

                        <td>
                            <a target="_blank" href="<?php echo e($File->file_path_directory); ?>"
                                class="ms-1 text-warning" style="text-decoration: none; color:black;">
                                <i class="<?php echo e($File->icon); ?>"></i>
                            </a>

                            <a target="_blank" href="<?php echo e($File->file_path_directory); ?>"
                                class="ms-1" style="text-decoration: none; color:black;">
                                <?php echo e($File->file_name); ?>

                            </a>




                        </td>
                        <td>
                            <a href="" style="text-decoration: none; color:black; "><?php echo e($File->file_size); ?></a>
                        </td>
                        <td><a href="" style="text-decoration: none; color:black; "><?php echo e($File->created_at); ?></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>

        <div>
            <?php $__errorArgs = ['file_request'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger fw-bold" style="font-size: 15px;">
                    <?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div>
            <?php $__errorArgs = ['file_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger fw-bold" style="font-size: 15px;">
                    <?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php if(Session::has('warning')): ?>
            <div class="alert alert-warning text-black">
                <?php echo e(Session::get('warning')); ?>

            </div>
        <?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b)): ?>
<?php $component = $__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b; ?>
<?php unset($__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b); ?>
<?php endif; ?>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/ProjectFiles/Auth/Account/File_Manager.blade.php ENDPATH**/ ?>