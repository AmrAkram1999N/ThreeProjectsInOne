<?php if (isset($component)) { $__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AccountLayout::class, []); ?>
<?php $component->withName('Account-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>



     <?php $__env->slot('PageName', null, []); ?> Account_Dashboard <?php $__env->endSlot(); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Your_Services</h1>
        <div class="btn-toolbar mb-2 mb-md-0">

        <div class="btn-group me-2">
                
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>

            
        </div>
    </div>

    


    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr class="text-center">
                    <th>ID</th>
                    <th scope="col">Name_Service</th>
                    <th scope="col">Your_boss</th>
                    <th scope="col">Enter_The_Work</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $AccountServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">

                        <td><?php echo e($Service->id); ?></td>
                        <td><?php echo e($Service->name_service); ?></td>
                        <td><?php echo e($Service->User->name); ?></td>
                        
                        <td><a class="btn btn-sm btn-outline-secondary text-success" href="<?php echo e(route('Chain.Account.Auth.'. $Service->name_service)); ?>">Enter</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>




        </table>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b)): ?>
<?php $component = $__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b; ?>
<?php unset($__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b); ?>
<?php endif; ?>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/ProjectFiles/Auth/Account/Account_Dash.blade.php ENDPATH**/ ?>