<!-- Click on Modal Button -->
<a class="nav-link" type="button" data-bs-toggle="modal" data-bs-target="#modalForm4">
    <?php echo e($lang); ?>

</a>

<!-- Modal -->
<div class="modal fade" id="modalForm4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-dark">
                <h3 class="modal-title text-white" id="exampleModalLabel"><?php echo e($headerThree); ?></h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>


            <div class="modal-body">
                <h5><?php echo e($headerFive); ?></h5>
                <hr style="height:3px;border:none;color:rgb(2, 2, 2);background-color:rgb(0, 0, 0);" />

                <p>
                    <?php echo e($paragraph); ?>

                </p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/components/Idea.blade.php ENDPATH**/ ?>