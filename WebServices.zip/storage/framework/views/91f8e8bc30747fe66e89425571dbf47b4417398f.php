<?php if (isset($component)) { $__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AccountLayout::class, []); ?>
<?php $component->withName('Account-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('PageName', null, []); ?> Back_Cards_Service <?php $__env->endSlot(); ?>

        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><span class="text-warning"><?php echo e($account->name); ?>:</span> <span
                    class="fs-3">Back_Cards_Service</span> </h1>
            <div class="btn-toolbar mb-2 mb-md-0">

                <div class="btn-group me-2">
                    <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                </div>

            </div>
        </div>


        <div class="table-responsive">
            <table class="table table-striped table-sm">
                <thead>
                    <tr class="text-center">
                        <th scope="col">id</th>
                        <th scope="col">clientname</th>
                        <th scope="col">clientnumber</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td> <?php echo e($Card->id); ?> </td>
                            <td> <?php echo e($Card->clientname); ?> </td>
                            <td> <?php echo e($Card->clientnumber); ?> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <form action="<?php echo e(route('Chain.Account.Auth.getClient')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-sm btn-outline-secondary bg-black" type="submit" role="button">
                    Get a Client
                </button>
            </form>

            <?php if(Session::has('status')): ?>
            <div class="alert alert-warning text-black">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b)): ?>
<?php $component = $__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b; ?>
<?php unset($__componentOriginal710d8bde111a6e196f50997eea459bbe24fe201b); ?>
<?php endif; ?>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/ProjectFiles/Auth/Account/Back_Cards_Service.blade.php ENDPATH**/ ?>