<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Back_Cards_Service.blade</title>
    <script src="https://kit.fontawesome.com/2c685a62ec.js" crossorigin="anonymous"></script>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/dashboard/">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
</head>

<body style="margin-top: 200px; background: rgb(22, 22, 22);">

    <div class="container" >
        <div class="row justify-content-center align-self-center">
            <div class="col-sm-6">
                <div class="jumbotron vertical-center text-center">
                    <h2 id="quote-content" class="display-5"><i class="fa fa-quote-left" aria-hidden="true"></i><i
                            class="fa fa-quote-right" aria-hidden="true"></i></h2>
                    <p id="quote-author" class="lead"><em></em></p>
                    <hr class="my-2">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-sm-1-4 text-left">
                            <a id="tweet" href="#">
                                <h2 class="display-4"><i class="fa fa-twitter" aria-hidden="true"></i></h2>
                            </a>
                        </div>
                        <?php if(Session::has('cleint')): ?>

                        <div class="alert alert-warning text-black">
                            <?php echo e(Session::get('cleint')); ?>

                        </div>
                        <?php endif; ?>

                        <div class="col-sm-1-4 text-right">
                            <form action="<?php echo e(route('Chain.Account.Public.clientClick')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button id="get-another-quote-button" type="submit"
                                class="btn btn-outline-secondary  bg-white btn-new-quote">Get Number</button>
                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/ProjectFiles/Public/Bank_Client_Card.blade.php ENDPATH**/ ?>