<a class="btn btn-sm btn-outline-secondary " type="button" data-bs-toggle="modal" href="#exampleModalToggle"
    role="button">
    <span class="text-danger"  data-feather="upload"></span>
    Upload_New_File
</a>


<div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel"
    tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-dark">
                <h5 class="modal-title text-danger" id="exampleModalToggleLabel">Uploading a New Files</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <form action="<?php echo e(route('Chain.Account.Auth.Upload', $path)); ?>" method="POST" files="true" accept="image/* , files/*, audio/* .pdf, .doc, .docx" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row gutters">
                            <div class="mb-3">
                                <label class="form-label ms-1 fs-6 fw-bold">Upload File</label>
                                <input type="file" name="file_request[]"
                                    class="form-control mb-0 <?php $__errorArgs = ['file_request'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                                    placeholder="Your file" value="<?php echo e(old('file_request')); ?>" required autofocus multiple>
                                <?php $__errorArgs = ['file_request'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger">
                                        <?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-1">
                                <div class="text-right">
                                    <button type="submit" class="btn btn-warning">+Upload</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/components/Upload_Button.blade.php ENDPATH**/ ?>