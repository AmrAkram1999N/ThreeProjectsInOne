<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title><?php echo e($lang['Titles']['cardView']); ?></title>
    <script src="https://kit.fontawesome.com/2c685a62ec.js" crossorigin="anonymous"></script>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/dashboard/">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/navbar.css">
    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

    </style>
</head>

<body style="background: rgb(26, 25, 25);">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark" aria-label="Eighth navbar example">
        <div class="container">
            <a class="navbar-brand" href="#"><?php echo e($lang['Navbar']['title']); ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07"
                aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarsExample07">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.Idea','data' => ['lang' => ''.e($lang['Navbar']['Idea']).'','headerThree' => ''.e($lang['Components']['idea']['h3']).'','headerFive' => ''.e($lang['Components']['idea']['h5']).'','paragraph' => ''.e($lang['Components']['idea']['p']).'']]); ?>
<?php $component->withName('Idea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['lang' => ''.e($lang['Navbar']['Idea']).'','headerThree' => ''.e($lang['Components']['idea']['h3']).'','headerFive' => ''.e($lang['Components']['idea']['h5']).'','paragraph' => ''.e($lang['Components']['idea']['p']).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </li>
                    <li class="nav-item">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.NoteOne','data' => ['lang' => ''.e($lang['Navbar']['N2']).'','headerThree' => ''.e($lang['Components']['N1']['h3']).'','headerFive' => ''.e($lang['Components']['N1']['h5']).'','paragraphOne' => ''.e($lang['Components']['N1']['p1']).'','paragraphTwo' => ''.e($lang['Components']['N1']['p2']).'','link' => ''.e($lang['Components']['N1']['a']).'','liOne' => ''.e($lang['Components']['N1']['ol']['1']).'','liTwo' => ''.e($lang['Components']['N1']['ol']['2']).'','liThree' => ''.e($lang['Components']['N1']['ol']['3']).'','liFour' => ''.e($lang['Components']['N1']['ol']['4']).'']]); ?>
<?php $component->withName('NoteOne'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['lang' => ''.e($lang['Navbar']['N2']).'','headerThree' => ''.e($lang['Components']['N1']['h3']).'','headerFive' => ''.e($lang['Components']['N1']['h5']).'','paragraphOne' => ''.e($lang['Components']['N1']['p1']).'','paragraphTwo' => ''.e($lang['Components']['N1']['p2']).'','link' => ''.e($lang['Components']['N1']['a']).'','liOne' => ''.e($lang['Components']['N1']['ol']['1']).'','liTwo' => ''.e($lang['Components']['N1']['ol']['2']).'','liThree' => ''.e($lang['Components']['N1']['ol']['3']).'','liFour' => ''.e($lang['Components']['N1']['ol']['4']).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </li>

                    <li class="nav-item">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.NoteTwo','data' => ['lang' => ''.e($lang['Navbar']['N3']).'','headerThree' => ''.e($lang['Components']['N2']['h3']).'','headerFive' => ''.e($lang['Components']['N2']['h5']).'','paragraphOne' => ''.e($lang['Components']['N2']['p1']).'','paragraphTwo' => ''.e($lang['Components']['N2']['p2']).'','link' => ''.e($lang['Components']['N2']['a']).'']]); ?>
<?php $component->withName('NoteTwo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['lang' => ''.e($lang['Navbar']['N3']).'','headerThree' => ''.e($lang['Components']['N2']['h3']).'','headerFive' => ''.e($lang['Components']['N2']['h5']).'','paragraphOne' => ''.e($lang['Components']['N2']['p1']).'','paragraphTwo' => ''.e($lang['Components']['N2']['p2']).'','link' => ''.e($lang['Components']['N2']['a']).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </li>
                    <li class="nav-item">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.NoteThree','data' => ['lang' => ''.e($lang['Navbar']['N4']).'','headerThree' => ''.e($lang['Components']['N3']['h']['h3']['1']).'','headerFiveOne' => ''.e($lang['Components']['N3']['h']['h5']['1']).'','headerFiveTwo' => ''.e($lang['Components']['N3']['h']['h5']['2']).'','headerFiveThree' => ''.e($lang['Components']['N3']['h']['h5']['3']).'','paragraphOne' => ''.e($lang['Components']['N3']['p']['1']).'','paragraphTwo' => ''.e($lang['Components']['N3']['p']['2']).'','link' => ''.e($lang['Components']['N3']['a']).'','olOnefOne' => ''.e($lang['Components']['N3']['ol1']['f']['1']).'','olOnefTwo' => ''.e($lang['Components']['N3']['ol1']['f']['2']).'','olOnepOne' => ''.e($lang['Components']['N3']['ol1']['p']['1']).'','olOnepTwo' => ''.e($lang['Components']['N3']['ol1']['p']['2']).'','olTwofOne' => ''.e($lang['Components']['N3']['ol2']['f']['1']).'','olTwofTwo' => ''.e($lang['Components']['N3']['ol2']['f']['2']).'','olTwopOne' => ''.e($lang['Components']['N3']['ol2']['p']['1']).'','olTwopTwo' => ''.e($lang['Components']['N3']['ol2']['p']['2']).'']]); ?>
<?php $component->withName('NoteThree'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['lang' => ''.e($lang['Navbar']['N4']).'','headerThree' => ''.e($lang['Components']['N3']['h']['h3']['1']).'','headerFiveOne' => ''.e($lang['Components']['N3']['h']['h5']['1']).'','headerFiveTwo' => ''.e($lang['Components']['N3']['h']['h5']['2']).'','headerFiveThree' => ''.e($lang['Components']['N3']['h']['h5']['3']).'','paragraphOne' => ''.e($lang['Components']['N3']['p']['1']).'','paragraphTwo' => ''.e($lang['Components']['N3']['p']['2']).'','link' => ''.e($lang['Components']['N3']['a']).'','olOnefOne' => ''.e($lang['Components']['N3']['ol1']['f']['1']).'','olOnefTwo' => ''.e($lang['Components']['N3']['ol1']['f']['2']).'','olOnepOne' => ''.e($lang['Components']['N3']['ol1']['p']['1']).'','olOnepTwo' => ''.e($lang['Components']['N3']['ol1']['p']['2']).'','olTwofOne' => ''.e($lang['Components']['N3']['ol2']['f']['1']).'','olTwofTwo' => ''.e($lang['Components']['N3']['ol2']['f']['2']).'','olTwopOne' => ''.e($lang['Components']['N3']['ol2']['p']['1']).'','olTwopTwo' => ''.e($lang['Components']['N3']['ol2']['p']['2']).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownXxl" data-bs-toggle="dropdown"
                            aria-expanded="false"><?php echo e($lang['Navbar']['lang']['title']); ?></a>
                        <ul class="dropdown-menu" aria-labelledby="dropdownXxl">
                            <li><a class="dropdown-item" href="<?php echo e(route('Chain.Public.langChoice', 'ar')); ?>"><?php echo e($lang['Navbar']['lang']['one']); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('Chain.Public.langChoice', 'en')); ?>"><?php echo e($lang['Navbar']['lang']['two']); ?></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <?php if(Session::has('number')): ?>
        <div class="alert alert-warning text-black">
            <?php echo e(Session::get('number')); ?>

        </div>
    <?php endif; ?>

    <?php if(Session::has('time')): ?>
        <div class="alert alert-warning text-black">
            <?php echo e($lang['p']['prefix'] .' '); ?> <?php echo e(session()->pull('time', 0)); ?> <?php echo e(' ' . $lang['p']['suffix']); ?>

        </div>
    <?php endif; ?>

    <div class="card" style="width: 22rem; margin:0 auto; margin-top: 150px;">

        <div class="card-header text-success text-center">
            <h3><?php echo e($lang['Titles']['h3']); ?></h3>
        </div>
        <form action="<?php echo e(route('Chain.Public.getNumber')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body text-center">
                <h4 class="card-title "><?php echo e($lang['Titles']['h4']); ?></h4>

                <p class="card-text fs-4">
                    <?php echo e($number); ?>

                </p>

                <button class="btn btn-primary" type="submit"><?php echo e($lang['Titles']['button']); ?></button>


            </div>
            <div class="card-footer text-center">

                <button class="btn btn-theme float-left bg-dark text-white" type="submit"
                    formaction="<?php echo e(route('Chain.Public.previousNumber', $number)); ?>">

                    < </button>

                        <button class="btn btn-theme bg-dark text-white " type="button">+
                        </button>
                        <button class="btn btn-theme float-right bg-dark text-white" type="submit"
                            formaction="<?php echo e(route('Chain.Public.nextNumber', $number)); ?>"> >
                        </button>

            </div>
        </form>
    </div>
    <script src="/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js"
        integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"
        integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous">
    </script>
    <script src="/js/dashboard.js"></script>
</body>

</html>
<?php /**PATH E:\Work in this Time\UCAST\Projects\WebServices\resources\views/ProjectFiles/Auth/Account/cardView.blade.php ENDPATH**/ ?>